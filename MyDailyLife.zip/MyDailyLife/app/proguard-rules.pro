# My Daily Life uses no reflection or third-party serialization, so the default
# Android/Compose shrinking rules are enough. Add project-specific rules below if needed.
