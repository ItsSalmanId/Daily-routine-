package com.mydailylife.routine.logic

import com.mydailylife.routine.model.AppData
import com.mydailylife.routine.model.RoutineItem
import com.mydailylife.routine.model.Section
import com.mydailylife.routine.model.TaskItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class DailyLogicTest {

    private fun starter(): AppData =
        AppData(name = "Sara", routines = defaultRoutines { it }, dayKey = "2026-10-23")

    // ------------------------------------------------------------ starter data

    @Test
    fun starterRoutinesCoverAllSectionsWithUniqueIds() {
        val r = defaultRoutines { it }
        assertEquals(12, r.size)
        assertEquals(12, r.map { it.id }.toSet().size)
        assertEquals(3, r.count { it.section == Section.MEALS })
        assertEquals(3, r.count { it.section == Section.SKIN_MORNING })
        assertEquals(2, r.count { it.section == Section.SKIN_NIGHT })
        assertEquals(4, r.count { it.section == Section.HABITS })
    }

    // ------------------------------------------------------------ progress

    @Test
    fun progressStartsAtZeroAndCountsWaterAsOneItem() {
        val p = starter().progress()
        assertEquals(0, p.done)
        assertEquals(13, p.total) // 12 routine items + water
        assertEquals(0, p.percent)
    }

    @Test
    fun progressCountsRoutinesTasksAndWater() {
        var d = starter().addTask("Call mum", "t1").addTask("Pay bill", "t2")
        d = d.toggleRoutine("seed_breakfast").toggleRoutine("seed_lunch")
        d = d.toggleTask("t1")
        for (i in 0 until WATER_GOAL) d = d.tapWaterGlass(i)
        val p = d.progress()
        assertEquals(4, p.done) // 2 routines + 1 task + water
        assertEquals(15, p.total) // 12 + 2 tasks + water
        assertEquals(26, p.percent) // 4 * 100 / 15, rounded down
    }

    @Test
    fun hundredPercentOnlyWhenEverythingIsDone() {
        var d = starter().addTask("One task", "t1")
        d.routines.forEach { d = d.toggleRoutine(it.id) }
        d = d.toggleTask("t1")
        for (i in 0 until WATER_GOAL) d = d.tapWaterGlass(i)
        assertEquals(100, d.progress().percent)

        val almost = d.tapWaterGlass(WATER_GOAL - 1) // un-fill the last glass
        assertTrue(almost.progress().percent < 100)
    }

    @Test
    fun deletedRoutineNoLongerCountsAsDone() {
        val d = starter().toggleRoutine("seed_walk").deleteRoutine("seed_walk")
        assertEquals(0, d.progress().done)
        assertFalse("seed_walk" in d.doneIds)
        assertEquals(11, d.routines.size)
    }

    // ------------------------------------------------------------ toggling & water

    @Test
    fun toggleRoutineChecksAndUnchecks() {
        val on = starter().toggleRoutine("seed_sunscreen")
        assertTrue("seed_sunscreen" in on.doneIds)
        val off = on.toggleRoutine("seed_sunscreen")
        assertFalse("seed_sunscreen" in off.doneIds)
    }

    @Test
    fun toggleUnknownRoutineChangesNothing() {
        val d = starter()
        assertEquals(d, d.toggleRoutine("does-not-exist"))
    }

    @Test
    fun waterGlassTapsFillAndUnfill() {
        var d = starter().tapWaterGlass(2)
        assertEquals(3, d.waterCount)
        d = d.tapWaterGlass(2) // tapping the last filled glass empties it
        assertEquals(2, d.waterCount)
        d = d.tapWaterGlass(7)
        assertEquals(8, d.waterCount)
        d = d.tapWaterGlass(0)
        assertEquals(1, d.waterCount)
    }

    // ------------------------------------------------------------ custom routines

    @Test
    fun addEditDeleteRoutine() {
        var d = starter().addRoutine(Section.HABITS, "  Read 10 pages  ", "custom1")
        val added = d.routines.first { it.id == "custom1" }
        assertEquals("Read 10 pages", added.title)
        assertEquals(Section.HABITS, added.section)

        d = d.editRoutine("custom1", "Read 20 pages")
        assertEquals("Read 20 pages", d.routines.first { it.id == "custom1" }.title)

        d = d.deleteRoutine("custom1")
        assertTrue(d.routines.none { it.id == "custom1" })
    }

    @Test
    fun blankTitlesAreIgnored() {
        val d = starter()
        assertEquals(d, d.addRoutine(Section.MEALS, "   "))
        assertEquals(d, d.editRoutine("seed_lunch", ""))
        assertEquals(d, d.addTask("  "))
    }

    // ------------------------------------------------------------ tasks

    @Test
    fun addEditToggleDeleteTask() {
        var d = starter().addTask(" Buy fruit ", "t1")
        assertEquals("Buy fruit", d.tasks.single().title)
        assertFalse(d.tasks.single().done)

        d = d.editTask("t1", "Buy fruit and yoghurt")
        assertEquals("Buy fruit and yoghurt", d.tasks.single().title)

        d = d.toggleTask("t1")
        assertTrue(d.tasks.single().done)
        d = d.toggleTask("t1")
        assertFalse(d.tasks.single().done)

        d = d.deleteTask("t1")
        assertTrue(d.tasks.isEmpty())
    }

    // ------------------------------------------------------------ daily reset

    @Test
    fun sameDayDoesNotReset() {
        val d = starter().toggleRoutine("seed_breakfast").tapWaterGlass(3)
        assertEquals(d, d.rolloverIfNeeded("2026-10-23"))
    }

    @Test
    fun firstLaunchJustStampsTheDay() {
        val fresh = AppData(routines = defaultRoutines { it })
        val d = fresh.rolloverIfNeeded("2026-10-23")
        assertEquals("2026-10-23", d.dayKey)
        assertTrue(d.history.isEmpty())
    }

    @Test
    fun newDayStartsFreshButKeepsRoutinesAndUnfinishedTasks() {
        var d = starter().addRoutine(Section.SKIN_NIGHT, "Lip balm", "custom1")
        d = d.addTask("Done task", "t1").addTask("Open task", "t2")
        d = d.toggleRoutine("seed_breakfast").toggleRoutine("custom1").tapWaterGlass(4)
        d = d.toggleTask("t1")
        val before = d.progress()

        val next = d.rolloverIfNeeded("2026-10-24")

        assertEquals("2026-10-24", next.dayKey)
        assertTrue(next.doneIds.isEmpty())
        assertEquals(0, next.waterCount)
        // custom + built-in routines are preserved
        assertEquals(d.routines, next.routines)
        assertTrue(next.routines.any { it.id == "custom1" && it.title == "Lip balm" })
        // completed task removed, unfinished task carried over
        assertEquals(listOf(TaskItem("t2", "Open task", false)), next.tasks)
        // yesterday's result saved for the weekly chart
        assertEquals(before.percent, next.history["2026-10-23"])
        assertEquals(0, next.progress().done)
    }

    @Test
    fun missedDaysStillResetOnce() {
        val d = starter().toggleRoutine("seed_lunch")
        val next = d.rolloverIfNeeded("2026-10-30")
        assertEquals("2026-10-30", next.dayKey)
        assertTrue(next.doneIds.isEmpty())
        assertEquals(1, next.history.size)
    }

    @Test
    fun clockMovingBackwardsNeverWipesData() {
        val d = starter().toggleRoutine("seed_breakfast")
        assertEquals(d, d.rolloverIfNeeded("2026-10-20"))
    }

    @Test
    fun manualResetClearsTodayOnly() {
        var d = starter().addTask("Task", "t1")
        d = d.toggleRoutine("seed_walk").toggleTask("t1").tapWaterGlass(5)
        val r = d.resetToday()
        assertTrue(r.doneIds.isEmpty())
        assertEquals(0, r.waterCount)
        assertFalse(r.tasks.single().done)
        assertEquals(d.routines, r.routines)
        assertEquals(1, r.tasks.size)
    }

    @Test
    fun historyIsTrimmedToSixtyDays() {
        val big = (1..80).associate { n -> "2026-01-%02d-%02d".format(n / 10, n % 10) to 50 }
        val d = starter().copy(history = big)
        val next = d.rolloverIfNeeded("2026-10-24")
        assertEquals(60, next.history.size)
        assertTrue("2026-10-23" in next.history)
    }

    // ------------------------------------------------------------ weekly chart

    @Test
    fun lastSevenDaysMixesTodayHistoryAndGaps() {
        val today = LocalDate.of(2026, 10, 23)
        val d = starter()
            .copy(history = mapOf("2026-10-22" to 80, "2026-10-20" to 100))
            .toggleRoutine("seed_breakfast")
        val bars = d.lastDays(today)

        assertEquals(7, bars.size)
        assertEquals(LocalDate.of(2026, 10, 17), bars.first().date)
        assertEquals(today, bars.last().date)
        assertEquals(d.progress().percent, bars.last().percent) // today = live value (7%)
        assertEquals(80, bars[5].percent) // 22 Oct
        assertEquals(100, bars[3].percent) // 20 Oct
        assertNull(bars[4].percent) // 21 Oct: no data
        assertNull(bars[0].percent)
    }

    // ------------------------------------------------------------ misc

    @Test
    fun emptyDataHasZeroPercentWithoutDividingByZero() {
        assertEquals(0, Progress(0, 0).percent)
        val p = AppData().progress()
        assertEquals(1, p.total) // water only
        assertEquals(0, p.percent)
    }

    @Test
    fun routineItemEqualityIsByValue() {
        assertEquals(RoutineItem("a", Section.MEALS, "x"), RoutineItem("a", Section.MEALS, "x"))
    }
}
