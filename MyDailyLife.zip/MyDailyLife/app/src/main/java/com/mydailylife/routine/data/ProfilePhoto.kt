package com.mydailylife.routine.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import java.io.File
import kotlin.math.min
import kotlin.math.roundToInt

/** Copies a picked picture into the app's private folder as a small square JPEG. */
object ProfilePhoto {
    private const val TARGET_SIZE = 600

    fun saveFrom(context: Context, uri: Uri, out: File): Boolean {
        return try {
            val bitmap = decode(context, uri) ?: return false
            val side = min(bitmap.width, bitmap.height)
            val square = Bitmap.createBitmap(
                bitmap, (bitmap.width - side) / 2, (bitmap.height - side) / 2, side, side
            )
            out.outputStream().use { square.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun decode(context: Context, uri: Uri): Bitmap? {
        val resolver = context.contentResolver
        return if (Build.VERSION.SDK_INT >= 28) {
            // ImageDecoder also applies the photo's rotation automatically.
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(resolver, uri)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val shortSide = min(w, h)
                if (shortSide > TARGET_SIZE) {
                    val scale = TARGET_SIZE.toFloat() / shortSide
                    decoder.setTargetSize(
                        (w * scale).roundToInt().coerceAtLeast(1),
                        (h * scale).roundToInt().coerceAtLeast(1)
                    )
                }
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val shortSide = min(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (shortSide / (sample * 2) >= TARGET_SIZE) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        }
    }
}
