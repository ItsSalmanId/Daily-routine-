package com.mydailylife.routine.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydailylife.routine.AppViewModel
import com.mydailylife.routine.R
import com.mydailylife.routine.model.TaskItem

@Composable
fun TasksScreen(vm: AppViewModel, padding: PaddingValues) {
    val tasks = vm.data.tasks
    val active = tasks.filter { !it.done }
    val completed = tasks.filter { it.done }

    var newTask by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<TaskItem?>(null) }

    fun submit() {
        if (newTask.isNotBlank()) {
            vm.addTask(newTask)
            newTask = ""
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.tasks_title),
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Pastel.Ink,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newTask,
                    onValueChange = { if (it.length <= 80) newTask = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(stringResource(R.string.add_task_hint)) },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { submit() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { submit() },
                    enabled = newTask.isNotBlank(),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.height(56.dp)
                ) {
                    Text(stringResource(R.string.add), fontWeight = FontWeight.SemiBold)
                }
            }
        }

        if (tasks.isEmpty()) {
            item {
                PastelCard(color = Pastel.LavenderLight) {
                    Text(
                        text = stringResource(R.string.tasks_empty),
                        fontSize = 16.sp,
                        color = Pastel.InkSoft
                    )
                }
            }
        }

        items(active, key = { it.id }) { task ->
            TaskRow(
                task = task,
                accent = Pastel.LavenderDark,
                background = Color.White,
                onToggle = { vm.toggleTask(task.id) },
                onEdit = { editing = task }
            )
        }

        if (completed.isNotEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.completed) + " (${completed.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Pastel.InkSoft,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
            items(completed, key = { it.id }) { task ->
                TaskRow(
                    task = task,
                    accent = Pastel.MintDark,
                    background = Pastel.MintLight,
                    onToggle = { vm.toggleTask(task.id) },
                    onEdit = { editing = task }
                )
            }
        }
    }

    editing?.let { task ->
        TextEntryDialog(
            title = stringResource(R.string.edit_task),
            label = stringResource(R.string.task_name),
            initial = task.title,
            confirmLabel = stringResource(R.string.save),
            onConfirm = { text ->
                vm.editTask(task.id, text)
                editing = null
            },
            onDismiss = { editing = null },
            onDelete = {
                vm.deleteTask(task.id)
                editing = null
            }
        )
    }
}

@Composable
private fun TaskRow(
    task: TaskItem,
    accent: Color,
    background: Color,
    onToggle: () -> Unit,
    onEdit: () -> Unit
) {
    PastelCard(color = background) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .toggleable(value = task.done, role = Role.Checkbox, onValueChange = { onToggle() }),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CheckCircle(checked = task.done, accent = accent)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = task.title,
                    modifier = Modifier.weight(1f),
                    fontSize = 16.sp,
                    color = if (task.done) Pastel.InkSoft else Pastel.Ink,
                    textDecoration = if (task.done) TextDecoration.LineThrough else null
                )
            }
            SmallIconButton("✎", stringResource(R.string.edit), onEdit)
        }
    }
}
