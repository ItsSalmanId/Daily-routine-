package com.mydailylife.routine.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydailylife.routine.AppViewModel
import com.mydailylife.routine.R
import com.mydailylife.routine.logic.DayBar
import com.mydailylife.routine.logic.Progress
import com.mydailylife.routine.logic.WATER_GOAL
import com.mydailylife.routine.logic.lastDays
import com.mydailylife.routine.logic.progress
import com.mydailylife.routine.model.RoutineItem
import com.mydailylife.routine.model.Section
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private data class RoutineDialogState(val section: Section, val item: RoutineItem?)

@Composable
fun TodayScreen(vm: AppViewModel, padding: PaddingValues) {
    val data = vm.data
    var dialog by remember { mutableStateOf<RoutineDialogState?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { TodayHeader(name = data.name, today = vm.today, photo = vm.photo) }
        item { ProgressCard(progress = data.progress(), days = data.lastDays(vm.today)) }

        // ---- Meals + water
        item {
            PastelCard(color = Pastel.MintLight) {
                CardTitle("🍽️", stringResource(R.string.meals), Pastel.MintDark)
                RoutineRows(
                    items = data.routines.filter { it.section == Section.MEALS },
                    doneIds = data.doneIds,
                    accent = Pastel.MintDark,
                    onToggle = vm::toggleRoutine,
                    onEdit = { dialog = RoutineDialogState(Section.MEALS, it) }
                )
                WaterTracker(count = data.waterCount, onTap = vm::tapWater)
                AddButton { dialog = RoutineDialogState(Section.MEALS, null) }
            }
        }

        // ---- Skincare: morning + night
        item {
            PastelCard(color = Pastel.PinkLight) {
                CardTitle("🧖", stringResource(R.string.skincare), Pastel.PinkDark)
                SubHeading("☀️", stringResource(R.string.morning))
                RoutineRows(
                    items = data.routines.filter { it.section == Section.SKIN_MORNING },
                    doneIds = data.doneIds,
                    accent = Pastel.PinkDark,
                    onToggle = vm::toggleRoutine,
                    onEdit = { dialog = RoutineDialogState(Section.SKIN_MORNING, it) }
                )
                AddButton { dialog = RoutineDialogState(Section.SKIN_MORNING, null) }
                SubHeading("🌙", stringResource(R.string.night))
                RoutineRows(
                    items = data.routines.filter { it.section == Section.SKIN_NIGHT },
                    doneIds = data.doneIds,
                    accent = Pastel.PinkDark,
                    onToggle = vm::toggleRoutine,
                    onEdit = { dialog = RoutineDialogState(Section.SKIN_NIGHT, it) }
                )
                AddButton { dialog = RoutineDialogState(Section.SKIN_NIGHT, null) }
            }
        }

        // ---- Healthy habits
        item {
            PastelCard(color = Pastel.LavenderLight) {
                CardTitle("🌿", stringResource(R.string.habits), Pastel.LavenderDark)
                RoutineRows(
                    items = data.routines.filter { it.section == Section.HABITS },
                    doneIds = data.doneIds,
                    accent = Pastel.LavenderDark,
                    onToggle = vm::toggleRoutine,
                    onEdit = { dialog = RoutineDialogState(Section.HABITS, it) }
                )
                AddButton { dialog = RoutineDialogState(Section.HABITS, null) }
            }
        }
    }

    dialog?.let { state ->
        val editing = state.item
        TextEntryDialog(
            title = stringResource(if (editing == null) R.string.add_item_title else R.string.edit_item_title),
            label = stringResource(R.string.item_name),
            initial = editing?.title ?: "",
            confirmLabel = stringResource(if (editing == null) R.string.add else R.string.save),
            onConfirm = { text ->
                if (editing == null) vm.addRoutine(state.section, text) else vm.editRoutine(editing.id, text)
                dialog = null
            },
            onDismiss = { dialog = null },
            onDelete = editing?.let { item ->
                {
                    vm.deleteRoutine(item.id)
                    dialog = null
                }
            }
        )
    }
}

// ------------------------------------------------------------------ header

@Composable
private fun TodayHeader(name: String, today: LocalDate, photo: ImageBitmap?) {
    val dateText = remember(today) {
        today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
    }
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.hello_name, name),
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Pastel.Ink
            )
            Text(text = dateText, fontSize = 15.sp, color = Pastel.InkSoft)
        }
        Spacer(Modifier.width(12.dp))
        Avatar(photo = photo, name = name, size = 56.dp)
    }
}

// ------------------------------------------------------------------ progress

@Composable
private fun ProgressCard(progress: Progress, days: List<DayBar>) {
    val target = if (progress.total == 0) 0f else progress.done.toFloat() / progress.total
    val fraction by animateFloatAsState(targetValue = target, animationSpec = tween(600))

    val message = when {
        progress.total > 0 && progress.done == progress.total -> R.string.msg_all_done
        progress.percent >= 50 -> R.string.msg_keep_going
        progress.done > 0 -> R.string.msg_good_start
        else -> R.string.msg_lets_start
    }

    PastelCard(color = Color.White) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(112.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 14.dp.toPx()
                    val inset = strokeWidth / 2
                    val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                    drawArc(
                        color = Pastel.LavenderLight,
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = Offset(inset, inset),
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )
                    if (fraction > 0f) {
                        // Sweep gradients start at 3 o'clock, so rotate the whole arc to start at 12.
                        rotate(degrees = -90f) {
                            drawArc(
                                brush = Brush.sweepGradient(
                                    listOf(Pastel.Pink, Pastel.Lavender, Pastel.Mint, Pastel.Pink)
                                ),
                                startAngle = 0f,
                                sweepAngle = 360f * fraction,
                                useCenter = false,
                                topLeft = Offset(inset, inset),
                                size = arcSize,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }
                    }
                }
                Text(
                    text = "${progress.percent}%",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = Pastel.LavenderDark
                )
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.done_of, progress.done, progress.total),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Pastel.Ink
                )
                Spacer(Modifier.height(4.dp))
                Text(text = stringResource(message), fontSize = 15.sp, color = Pastel.InkSoft)
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.last_7_days),
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Pastel.InkSoft
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            days.forEach { day ->
                val percent = day.percent
                val barColor = when {
                    percent == null -> Pastel.LavenderLight
                    percent >= 100 -> Pastel.Mint
                    else -> Pastel.Lavender
                }
                val barHeight = 6.dp + 44.dp * ((percent ?: 0) / 100f)
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(18.dp)
                            .height(barHeight)
                            .clip(RoundedCornerShape(9.dp))
                            .background(barColor)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = day.date.dayOfWeek
                            .getDisplayName(TextStyle.SHORT, Locale.getDefault())
                            .take(2),
                        fontSize = 11.sp,
                        color = Pastel.InkSoft
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ pieces

@Composable
private fun SubHeading(emoji: String, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
    ) {
        Text(emoji, fontSize = 16.sp)
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Pastel.InkSoft)
    }
}

@Composable
private fun RoutineRows(
    items: List<RoutineItem>,
    doneIds: Set<String>,
    accent: Color,
    onToggle: (String) -> Unit,
    onEdit: (RoutineItem) -> Unit
) {
    items.forEach { item ->
        ChecklistRow(
            emoji = emojiFor(item),
            title = item.title,
            checked = item.id in doneIds,
            accent = accent,
            onToggle = { onToggle(item.id) },
            onEdit = { onEdit(item) }
        )
    }
}

@Composable
private fun AddButton(onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text("＋ " + stringResource(R.string.add), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun WaterTracker(count: Int, onTap: (Int) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💧", fontSize = 20.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.water),
                modifier = Modifier.weight(1f),
                fontSize = 16.sp,
                color = Pastel.Ink
            )
            Text(
                text = stringResource(R.string.water_count, count, WATER_GOAL),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Pastel.MintDark
            )
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            for (i in 0 until WATER_GOAL) {
                val description = stringResource(R.string.glass_n, i + 1)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = { onTap(i) })
                        .semantics { contentDescription = description },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "💧",
                        fontSize = 22.sp,
                        modifier = Modifier.alpha(if (i < count) 1f else 0.25f)
                    )
                }
            }
        }
    }
}
