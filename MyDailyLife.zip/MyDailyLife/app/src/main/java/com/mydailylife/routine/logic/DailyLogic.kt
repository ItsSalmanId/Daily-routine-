package com.mydailylife.routine.logic

import com.mydailylife.routine.model.AppData
import com.mydailylife.routine.model.RoutineItem
import com.mydailylife.routine.model.Section
import com.mydailylife.routine.model.TaskItem
import java.time.LocalDate
import java.util.UUID

/** Glasses of water that count as "done" for the day. */
const val WATER_GOAL = 8

private const val MAX_HISTORY_DAYS = 60

fun newId(): String = UUID.randomUUID().toString()

/** Completed items out of all items (routine items + tasks + the water goal). */
data class Progress(val done: Int, val total: Int) {
    /** Rounded down, so 100% only appears when everything is really done. */
    val percent: Int get() = if (total <= 0) 0 else done * 100 / total
}

/** One bar in the "last 7 days" chart. [percent] is null when there is no data for that day. */
data class DayBar(val date: LocalDate, val percent: Int?)

// ---------------------------------------------------------------- progress

fun AppData.progress(): Progress {
    val routineIds = routines.map { it.id }.toSet()
    val routineDone = doneIds.count { it in routineIds }
    val taskDone = tasks.count { it.done }
    val waterDone = if (waterCount >= WATER_GOAL) 1 else 0
    return Progress(
        done = routineDone + taskDone + waterDone,
        total = routines.size + tasks.size + 1
    )
}

fun AppData.lastDays(today: LocalDate, count: Int = 7): List<DayBar> =
    (count - 1 downTo 0).map { back ->
        val date = today.minusDays(back.toLong())
        val key = date.toString()
        val percent = if (key == dayKey) progress().percent else history[key]
        DayBar(date, percent)
    }

// ---------------------------------------------------------------- daily reset

/**
 * Starts a fresh checklist when the date has moved forward.
 * Routine items are kept; checkmarks and water are cleared; completed tasks are removed
 * and unfinished tasks carry over. The finished day's percentage goes into [AppData.history].
 * If the phone's clock moves backwards, nothing is wiped.
 */
fun AppData.rolloverIfNeeded(today: String): AppData {
    if (dayKey.isEmpty()) return copy(dayKey = today)
    if (today <= dayKey) return this
    val finished = progress()
    val newHistory = if (finished.total > 0) history + (dayKey to finished.percent) else history
    return copy(
        dayKey = today,
        doneIds = emptySet(),
        waterCount = 0,
        tasks = tasks.filterNot { it.done },
        history = newHistory.trimmed()
    )
}

/** Manual "reset today's checklist" button. */
fun AppData.resetToday(): AppData =
    copy(doneIds = emptySet(), waterCount = 0, tasks = tasks.map { it.copy(done = false) })

private fun Map<String, Int>.trimmed(): Map<String, Int> =
    if (size <= MAX_HISTORY_DAYS) this
    else entries.sortedBy { it.key }.takeLast(MAX_HISTORY_DAYS).associate { it.key to it.value }

// ---------------------------------------------------------------- routine items

fun AppData.toggleRoutine(id: String): AppData {
    if (routines.none { it.id == id }) return this
    return copy(doneIds = if (id in doneIds) doneIds - id else doneIds + id)
}

fun AppData.addRoutine(section: Section, title: String, id: String = newId()): AppData {
    val t = title.trim()
    if (t.isEmpty()) return this
    return copy(routines = routines + RoutineItem(id, section, t))
}

fun AppData.editRoutine(id: String, title: String): AppData {
    val t = title.trim()
    if (t.isEmpty()) return this
    return copy(routines = routines.map { if (it.id == id) it.copy(title = t) else it })
}

fun AppData.deleteRoutine(id: String): AppData =
    copy(routines = routines.filterNot { it.id == id }, doneIds = doneIds - id)

// ---------------------------------------------------------------- water

/** Tapping glass [index] fills up to it; tapping the last filled glass empties it again. */
fun AppData.tapWaterGlass(index: Int): AppData {
    val target = if (waterCount == index + 1) index else index + 1
    return copy(waterCount = target.coerceIn(0, WATER_GOAL))
}

// ---------------------------------------------------------------- tasks

fun AppData.addTask(title: String, id: String = newId()): AppData {
    val t = title.trim()
    if (t.isEmpty()) return this
    return copy(tasks = tasks + TaskItem(id, t))
}

fun AppData.editTask(id: String, title: String): AppData {
    val t = title.trim()
    if (t.isEmpty()) return this
    return copy(tasks = tasks.map { if (it.id == id) it.copy(title = t) else it })
}

fun AppData.toggleTask(id: String): AppData =
    copy(tasks = tasks.map { if (it.id == id) it.copy(done = !it.done) else it })

fun AppData.deleteTask(id: String): AppData =
    copy(tasks = tasks.filterNot { it.id == id })

// ---------------------------------------------------------------- starter routines

/** Starter routine keys, in display order. [title] turns a key into the (translated) text. */
fun defaultRoutines(title: (String) -> String): List<RoutineItem> = listOf(
    RoutineItem("seed_breakfast", Section.MEALS, title("seed_breakfast")),
    RoutineItem("seed_lunch", Section.MEALS, title("seed_lunch")),
    RoutineItem("seed_dinner", Section.MEALS, title("seed_dinner")),
    RoutineItem("seed_face_wash", Section.SKIN_MORNING, title("seed_face_wash")),
    RoutineItem("seed_moisturizer", Section.SKIN_MORNING, title("seed_moisturizer")),
    RoutineItem("seed_sunscreen", Section.SKIN_MORNING, title("seed_sunscreen")),
    RoutineItem("seed_night_cleanse", Section.SKIN_NIGHT, title("seed_night_cleanse")),
    RoutineItem("seed_night_moisturizer", Section.SKIN_NIGHT, title("seed_night_moisturizer")),
    RoutineItem("seed_walk", Section.HABITS, title("seed_walk")),
    RoutineItem("seed_exercise", Section.HABITS, title("seed_exercise")),
    RoutineItem("seed_sleep", Section.HABITS, title("seed_sleep")),
    RoutineItem("seed_self_care", Section.HABITS, title("seed_self_care"))
)
