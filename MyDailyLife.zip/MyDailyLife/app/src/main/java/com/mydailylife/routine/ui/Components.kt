package com.mydailylife.routine.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydailylife.routine.R
import com.mydailylife.routine.model.RoutineItem
import com.mydailylife.routine.model.Section

/** A soft, rounded card used for every block on screen. */
@Composable
fun PastelCard(
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

/** Card heading: an emoji and a title. */
@Composable
fun CardTitle(emoji: String, title: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
        Text(emoji, fontSize = 22.sp)
        Spacer(Modifier.width(8.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

/** Round tick box. */
@Composable
fun CheckCircle(checked: Boolean, accent: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(if (checked) accent else Color.White.copy(alpha = 0.75f))
            .border(2.dp, accent, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (checked) {
            Text("✓", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** A small round button with a symbol (used for the edit pencil). */
@Composable
fun SmallIconButton(symbol: String, description: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(role = Role.Button, onClickLabel = description, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Text(symbol, fontSize = 18.sp, color = Pastel.InkSoft)
    }
}

/** One checklist line: tap anywhere on the text to tick it, tap the pencil to edit. */
@Composable
fun ChecklistRow(
    emoji: String,
    title: String,
    checked: Boolean,
    accent: Color,
    onToggle: () -> Unit,
    onEdit: () -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Row(
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 48.dp)
                .clip(RoundedCornerShape(16.dp))
                .toggleable(value = checked, role = Role.Checkbox, onValueChange = { onToggle() })
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CheckCircle(checked = checked, accent = accent)
            Spacer(Modifier.width(12.dp))
            Text(emoji, fontSize = 20.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                text = title,
                modifier = Modifier.weight(1f),
                fontSize = 16.sp,
                color = if (checked) Pastel.InkSoft else Pastel.Ink,
                textDecoration = if (checked) TextDecoration.LineThrough else null
            )
        }
        SmallIconButton("✎", stringResource(R.string.edit), onEdit)
    }
}

/** Round profile picture, or the first letter of the name when there is no photo. */
@Composable
fun Avatar(photo: ImageBitmap?, name: String, size: Dp, modifier: Modifier = Modifier) {
    if (photo != null) {
        Image(
            bitmap = photo,
            contentDescription = stringResource(R.string.profile_photo),
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .border(3.dp, Pastel.Pink, CircleShape)
        )
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .background(Pastel.LavenderLight)
                .border(3.dp, Pastel.Lavender, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = name.trim().take(1).uppercase().ifEmpty { "🌸" },
                fontSize = (size.value / 2.4f).sp,
                fontWeight = FontWeight.Bold,
                color = Pastel.LavenderDark
            )
        }
    }
}

/** A small pop-up with one text box. Shows a Delete button when [onDelete] is given. */
@Composable
fun TextEntryDialog(
    title: String,
    label: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    var text by remember { mutableStateOf(initial) }
    val canSave = text.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        containerColor = Color.White,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { if (it.length <= 80) text = it },
                label = { Text(label) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (canSave) onConfirm(text) })
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = canSave) { Text(confirmLabel) }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.End) {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text(stringResource(R.string.delete), color = Pastel.PinkDark)
                    }
                }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        }
    )
}

/** Picks a friendly emoji for a routine item. */
fun emojiFor(item: RoutineItem): String = when (item.id) {
    "seed_breakfast" -> "🥣"
    "seed_lunch" -> "🍛"
    "seed_dinner" -> "🍲"
    "seed_face_wash" -> "🧼"
    "seed_moisturizer" -> "🧴"
    "seed_sunscreen" -> "🌞"
    "seed_night_cleanse" -> "🧼"
    "seed_night_moisturizer" -> "🧴"
    "seed_walk" -> "🚶"
    "seed_exercise" -> "🧘"
    "seed_sleep" -> "😴"
    "seed_self_care" -> "💆"
    else -> when (item.section) {
        Section.MEALS -> "🍽️"
        Section.SKIN_MORNING -> "☀️"
        Section.SKIN_NIGHT -> "🌙"
        Section.HABITS -> "🌿"
    }
}
