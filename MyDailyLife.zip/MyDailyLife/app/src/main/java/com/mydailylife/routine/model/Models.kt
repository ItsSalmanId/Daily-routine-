package com.mydailylife.routine.model

/** The groups of routine items shown on the Today screen. */
enum class Section(val key: String) {
    MEALS("meals"),
    SKIN_MORNING("skin_morning"),
    SKIN_NIGHT("skin_night"),
    HABITS("habits");

    companion object {
        fun fromKey(key: String): Section? = entries.firstOrNull { it.key == key }
    }
}

/** A repeating routine item (e.g. "Sunscreen"). It stays forever; only its checkmark resets each day. */
data class RoutineItem(val id: String, val section: Section, val title: String)

/** A one-off task. Completed tasks are cleared on the next day; unfinished ones carry over. */
data class TaskItem(val id: String, val title: String, val done: Boolean = false)

/** Everything the app saves on the device. */
data class AppData(
    val name: String = "",
    val routines: List<RoutineItem> = emptyList(),
    val tasks: List<TaskItem> = emptyList(),
    /** The day (yyyy-MM-dd) that [doneIds] and [waterCount] belong to. */
    val dayKey: String = "",
    val doneIds: Set<String> = emptySet(),
    val waterCount: Int = 0,
    /** Finished days: yyyy-MM-dd -> percent complete. */
    val history: Map<String, Int> = emptyMap()
)
