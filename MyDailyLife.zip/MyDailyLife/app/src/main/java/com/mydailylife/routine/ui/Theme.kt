package com.mydailylife.routine.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** The My Daily Life palette: lavender, pink and mint pastels with soft, readable text colours. */
object Pastel {
    val Background = Color(0xFFFAF7FF)

    val Lavender = Color(0xFFB9A8F0)
    val LavenderLight = Color(0xFFEDE7FB)
    val LavenderDark = Color(0xFF7A68B5)

    val Pink = Color(0xFFF5A3C7)
    val PinkLight = Color(0xFFFFE3EF)
    val PinkDark = Color(0xFFB04677)

    val Mint = Color(0xFF8DDBBF)
    val MintLight = Color(0xFFDDF7EC)
    val MintDark = Color(0xFF2F8A6B)

    val Ink = Color(0xFF3B3552)
    val InkSoft = Color(0xFF6F6988)
}

@Composable
fun MyDailyLifeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Pastel.LavenderDark,
            onPrimary = Color.White,
            primaryContainer = Pastel.LavenderLight,
            onPrimaryContainer = Pastel.Ink,
            secondary = Pastel.PinkDark,
            onSecondary = Color.White,
            secondaryContainer = Pastel.PinkLight,
            onSecondaryContainer = Pastel.Ink,
            tertiary = Pastel.MintDark,
            tertiaryContainer = Pastel.MintLight,
            background = Pastel.Background,
            onBackground = Pastel.Ink,
            surface = Color.White,
            onSurface = Pastel.Ink,
            surfaceVariant = Pastel.LavenderLight,
            onSurfaceVariant = Pastel.InkSoft,
            outline = Pastel.Lavender
        ),
        shapes = Shapes(
            small = RoundedCornerShape(14.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp)
        ),
        content = content
    )
}
