package com.mydailylife.routine

import android.app.Application
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import com.mydailylife.routine.data.ProfilePhoto
import com.mydailylife.routine.data.Storage
import com.mydailylife.routine.logic.addRoutine
import com.mydailylife.routine.logic.addTask
import com.mydailylife.routine.logic.defaultRoutines
import com.mydailylife.routine.logic.deleteRoutine
import com.mydailylife.routine.logic.deleteTask
import com.mydailylife.routine.logic.editRoutine
import com.mydailylife.routine.logic.editTask
import com.mydailylife.routine.logic.resetToday
import com.mydailylife.routine.logic.rolloverIfNeeded
import com.mydailylife.routine.logic.tapWaterGlass
import com.mydailylife.routine.logic.toggleRoutine
import com.mydailylife.routine.logic.toggleTask
import com.mydailylife.routine.model.AppData
import com.mydailylife.routine.model.Section
import java.io.File
import java.time.LocalDate
import kotlin.concurrent.thread

/** Holds the app's state, applies changes and saves them to the device after every change. */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val storage = Storage(app)
    private val photoFile = File(app.filesDir, "profile.jpg")
    private val mainHandler = Handler(Looper.getMainLooper())

    /** The current calendar day, refreshed whenever the app comes to the front. */
    var today by mutableStateOf(LocalDate.now())
        private set

    var data by mutableStateOf(loadInitial())
        private set

    var photo by mutableStateOf(readPhoto())
        private set

    // ------------------------------------------------------------ setup

    private fun loadInitial(): AppData {
        val saved = storage.load() ?: AppData(routines = defaultRoutines(::seedTitle))
        val fresh = saved.rolloverIfNeeded(LocalDate.now().toString())
        storage.save(fresh)
        return fresh
    }

    private fun seedTitle(key: String): String {
        val res = when (key) {
            "seed_breakfast" -> R.string.seed_breakfast
            "seed_lunch" -> R.string.seed_lunch
            "seed_dinner" -> R.string.seed_dinner
            "seed_face_wash" -> R.string.seed_face_wash
            "seed_moisturizer" -> R.string.seed_moisturizer
            "seed_sunscreen" -> R.string.seed_sunscreen
            "seed_night_cleanse" -> R.string.seed_night_cleanse
            "seed_night_moisturizer" -> R.string.seed_night_moisturizer
            "seed_walk" -> R.string.seed_walk
            "seed_exercise" -> R.string.seed_exercise
            "seed_sleep" -> R.string.seed_sleep
            "seed_self_care" -> R.string.seed_self_care
            else -> return key
        }
        return getApplication<Application>().getString(res)
    }

    private fun readPhoto(): ImageBitmap? =
        if (photoFile.exists()) BitmapFactory.decodeFile(photoFile.path)?.asImageBitmap() else null

    private fun update(change: AppData.() -> AppData) {
        val next = data.change()
        if (next != data) {
            data = next
            storage.save(next)
        }
    }

    // ------------------------------------------------------------ daily reset

    /** Called every time the app comes to the front, so a new day always starts a fresh checklist. */
    fun refreshDay() {
        today = LocalDate.now()
        val key = today.toString()
        update { this.rolloverIfNeeded(key) }
    }

    fun resetToday() = update { this.resetToday() }

    // ------------------------------------------------------------ profile

    fun saveName(name: String) = update { copy(name = name.trim()) }

    fun setPhoto(uri: Uri) {
        thread {
            val ok = ProfilePhoto.saveFrom(getApplication<Application>(), uri, photoFile)
            if (ok) {
                val bitmap = readPhoto()
                mainHandler.post { photo = bitmap }
            }
        }
    }

    fun removePhoto() {
        photoFile.delete()
        photo = null
    }

    // ------------------------------------------------------------ routine items

    fun toggleRoutine(id: String) = update { this.toggleRoutine(id) }
    fun addRoutine(section: Section, title: String) = update { this.addRoutine(section, title) }
    fun editRoutine(id: String, title: String) = update { this.editRoutine(id, title) }
    fun deleteRoutine(id: String) = update { this.deleteRoutine(id) }
    fun tapWater(index: Int) = update { this.tapWaterGlass(index) }

    // ------------------------------------------------------------ tasks

    fun addTask(title: String) = update { this.addTask(title) }
    fun editTask(id: String, title: String) = update { this.editTask(id, title) }
    fun toggleTask(id: String) = update { this.toggleTask(id) }
    fun deleteTask(id: String) = update { this.deleteTask(id) }
}
