package com.mydailylife.routine.data

import android.content.Context
import com.mydailylife.routine.logic.newId
import com.mydailylife.routine.model.AppData
import com.mydailylife.routine.model.RoutineItem
import com.mydailylife.routine.model.Section
import com.mydailylife.routine.model.TaskItem
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Turns [AppData] into a small JSON string and back. Uses the JSON classes built into Android. */
object DataCodec {

    fun encode(d: AppData): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("name", d.name)
        root.put("dayKey", d.dayKey)
        root.put("water", d.waterCount)
        root.put("done", JSONArray(d.doneIds.toList()))

        val routines = JSONArray()
        d.routines.forEach { r ->
            routines.put(
                JSONObject().put("id", r.id).put("section", r.section.key).put("title", r.title)
            )
        }
        root.put("routines", routines)

        val tasks = JSONArray()
        d.tasks.forEach { t ->
            tasks.put(JSONObject().put("id", t.id).put("title", t.title).put("done", t.done))
        }
        root.put("tasks", tasks)

        val history = JSONObject()
        d.history.forEach { (day, percent) -> history.put(day, percent) }
        root.put("history", history)

        return root.toString()
    }

    /** Returns null if [text] is not valid saved data. */
    fun decode(text: String): AppData? = try {
        val o = JSONObject(text)

        val routines = mutableListOf<RoutineItem>()
        o.optJSONArray("routines")?.let { arr ->
            for (i in 0 until arr.length()) {
                val r = arr.optJSONObject(i) ?: continue
                val section = Section.fromKey(r.optString("section")) ?: continue
                val title = r.optString("title")
                if (title.isBlank()) continue
                routines.add(RoutineItem(r.optString("id").ifEmpty { newId() }, section, title))
            }
        }

        val tasks = mutableListOf<TaskItem>()
        o.optJSONArray("tasks")?.let { arr ->
            for (i in 0 until arr.length()) {
                val t = arr.optJSONObject(i) ?: continue
                val title = t.optString("title")
                if (title.isBlank()) continue
                tasks.add(TaskItem(t.optString("id").ifEmpty { newId() }, title, t.optBoolean("done")))
            }
        }

        val done = mutableSetOf<String>()
        o.optJSONArray("done")?.let { arr ->
            for (i in 0 until arr.length()) done.add(arr.optString(i))
        }

        val history = mutableMapOf<String, Int>()
        o.optJSONObject("history")?.let { h ->
            val keys = h.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                history[k] = h.optInt(k)
            }
        }

        AppData(
            name = o.optString("name"),
            routines = routines,
            tasks = tasks,
            dayKey = o.optString("dayKey"),
            doneIds = done,
            waterCount = o.optInt("water"),
            history = history
        )
    } catch (e: JSONException) {
        null
    }
}

/** Saves and loads [AppData] in the app's private storage (nothing leaves the phone). */
class Storage(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("my_daily_life", Context.MODE_PRIVATE)

    fun load(): AppData? = prefs.getString(KEY, null)?.let { DataCodec.decode(it) }

    fun save(data: AppData) {
        prefs.edit().putString(KEY, DataCodec.encode(data)).apply()
    }

    private companion object {
        const val KEY = "state"
    }
}
