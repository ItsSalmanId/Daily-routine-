package com.mydailylife.routine.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydailylife.routine.AppViewModel
import com.mydailylife.routine.R

// ------------------------------------------------------------------ Me tab

@Composable
fun ProfileScreen(vm: AppViewModel, padding: PaddingValues) {
    var name by remember(vm.data.name) { mutableStateOf(vm.data.name) }
    var confirmReset by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setPhoto(uri)
    }
    fun pickPhoto() {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding())
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = stringResource(R.string.me_title),
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Pastel.Ink
        )

        PastelCard(color = Pastel.PinkLight) {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Avatar(photo = vm.photo, name = vm.data.name, size = 112.dp)
            }
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = { pickPhoto() }) {
                    Text(
                        stringResource(if (vm.photo == null) R.string.add_photo else R.string.change_photo)
                    )
                }
                if (vm.photo != null) {
                    TextButton(onClick = { vm.removePhoto() }) {
                        Text(stringResource(R.string.remove_photo), color = Pastel.PinkDark)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            NameField(value = name, onChange = { name = it }, onDone = {
                if (name.isNotBlank()) vm.saveName(name)
            })
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { vm.saveName(name) },
                enabled = name.isNotBlank() && name.trim() != vm.data.name,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.save_name))
            }
        }

        PastelCard(color = Pastel.MintLight) {
            CardTitle("🌅", stringResource(R.string.reset_title), Pastel.MintDark)
            Text(
                text = stringResource(R.string.reset_desc),
                fontSize = 15.sp,
                color = Pastel.InkSoft
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.reset_button), color = Pastel.MintDark)
            }
        }

        PastelCard(color = Pastel.LavenderLight) {
            CardTitle("🔒", stringResource(R.string.privacy_title), Pastel.LavenderDark)
            Text(
                text = stringResource(R.string.privacy_text),
                fontSize = 15.sp,
                color = Pastel.InkSoft
            )
        }

        Text(
            text = stringResource(R.string.version),
            fontSize = 13.sp,
            color = Pastel.InkSoft,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            shape = RoundedCornerShape(28.dp),
            containerColor = Color.White,
            title = { Text(stringResource(R.string.reset_confirm_title)) },
            text = { Text(stringResource(R.string.reset_confirm_msg)) },
            confirmButton = {
                TextButton(onClick = {
                    vm.resetToday()
                    confirmReset = false
                }) { Text(stringResource(R.string.reset_confirm_yes)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

// ------------------------------------------------------------------ first-run welcome

@Composable
fun OnboardingScreen(vm: AppViewModel) {
    var name by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setPhoto(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Pastel.Background)
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🌸", fontSize = 56.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.welcome_title),
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Pastel.Ink,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.welcome_sub),
            fontSize = 16.sp,
            color = Pastel.InkSoft,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))

        Avatar(photo = vm.photo, name = name, size = 120.dp)
        Spacer(Modifier.height(8.dp))
        TextButton(
            onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        ) {
            Text(
                stringResource(if (vm.photo == null) R.string.add_photo else R.string.change_photo),
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(8.dp))

        NameField(value = name, onChange = { name = it }, onDone = {
            if (name.isNotBlank()) vm.saveName(name)
        })
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.saveName(name) },
            enabled = name.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            colors = ButtonDefaults.buttonColors()
        ) {
            Text(stringResource(R.string.get_started), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

// ------------------------------------------------------------------ shared

@Composable
private fun NameField(value: String, onChange: (String) -> Unit, onDone: () -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 30) onChange(it) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(stringResource(R.string.your_name)) },
        singleLine = true,
        shape = RoundedCornerShape(20.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White
        )
    )
}
