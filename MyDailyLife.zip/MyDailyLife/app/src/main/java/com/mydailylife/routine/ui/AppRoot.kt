package com.mydailylife.routine.ui

import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.sp
import com.mydailylife.routine.AppViewModel
import com.mydailylife.routine.R

/** First launch shows the welcome page; once there is a name, the three-tab app appears. */
@Composable
fun AppRoot(vm: AppViewModel) {
    if (vm.data.name.isBlank()) {
        OnboardingScreen(vm)
    } else {
        MainScreen(vm)
    }
}

@Composable
private fun MainScreen(vm: AppViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }

    val labels = listOf(
        stringResource(R.string.tab_today),
        stringResource(R.string.tab_tasks),
        stringResource(R.string.tab_me)
    )
    val emojis = listOf("🌸", "✅", "💜")

    Scaffold(
        containerColor = Pastel.Background,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                labels.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Text(emojis[index], fontSize = 22.sp) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Pastel.LavenderLight,
                            selectedTextColor = Pastel.LavenderDark,
                            unselectedTextColor = Pastel.InkSoft
                        )
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> TodayScreen(vm, padding)
            1 -> TasksScreen(vm, padding)
            else -> ProfileScreen(vm, padding)
        }
    }
}
